package jp.example.kindlescreenshotpdf

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private var intervalMs = 1500L
    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val service = Intent(this, CaptureService::class.java).apply {
                    action = CaptureService.ACTION_START
                    putExtra(CaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(CaptureService.EXTRA_RESULT_DATA, result.data)
                    putExtra(CaptureService.EXTRA_INTERVAL, intervalMs)
                }
                ContextCompat.startForegroundService(this, service)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                var interval by remember { mutableStateOf("1500") }
                var status by remember { mutableStateOf("準備完了") }
                Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Screenshot PDF Capture", style = MaterialTheme.typography.headlineSmall)
                    Text("許可された画面を撮影し、画像として端末に保存します。")
                    OutlinedTextField(
                        value = interval,
                        onValueChange = { interval = it.filter(Char::isDigit).take(5) },
                        label = { Text("自動撮影間隔（ミリ秒）") },
                        supportingText = { Text("500〜60000。自動撮影中のページ送りは手動です。") },
                        singleLine = true
                    )
                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            intervalMs = (interval.toLongOrNull() ?: 1500L).coerceIn(500L, 60000L)
                            if (!Settings.canDrawOverlays(this@MainActivity)) {
                                status = "次の設定画面で「他のアプリの上に重ねて表示」を許可してください。"
                                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                            } else {
                                val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                                projectionLauncher.launch(manager.createScreenCaptureIntent())
                            }
                        }
                    ) { Text("画面取得を許可して開始") }
                    OutlinedButton(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            stopService(Intent(this@MainActivity, CaptureService::class.java))
                            status = "停止しました"
                        }
                    ) { Text("キャプチャを終了") }
                    Text(status)
                    HorizontalDivider()
                    Text("使い方", style = MaterialTheme.typography.titleMedium)
                    Text("1. オーバーレイ表示を許可します。")
                    Text("2. 画面取得のシステム確認で開始を許可します。")
                    Text("3. 対象アプリを開き、浮動パネルで撮影します。")
                    Text("4. 画像は Pictures/KindleScreenshotPDF に保存されます。")
                    Text("5. PWAの「画像を選択」で複数画像を読み込み、PDFを作成します。")
                    Text("対象アプリが画面取得を禁止している場合は撮影できません。保護の回避は行いません。",
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
