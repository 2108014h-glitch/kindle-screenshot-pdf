package jp.example.kindlescreenshotpdf

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    companion object {
        const val ACTION_START = "capture.START"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        const val EXTRA_INTERVAL = "interval"
        private const val CHANNEL = "screen_capture"
        private const val NOTIFICATION_ID = 73
    }

    private val handler = Handler(Looper.getMainLooper())
    private val pending = AtomicBoolean(false)
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var wm: WindowManager? = null
    private var panel: LinearLayout? = null
    private var panelAdded = false
    private var auto = false
    private var count = 0
    private var interval = 1500L
    private var timeout: Runnable? = null
    private lateinit var status: TextView

    private val autoTask = object : Runnable {
        override fun run() {
            if (auto) {
                takeShot()
                handler.postDelayed(this, interval)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_START) return START_NOT_STICKY
        interval = intent.getLongExtra(EXTRA_INTERVAL, 1500L).coerceIn(500L, 60000L)
        createChannel()
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Screenshot PDF Capture")
            .setContentText("画面取得中")
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIFICATION_ID, notification)

        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            intent.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        val metrics = resources.displayMetrics
        reader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 3)
        reader?.setOnImageAvailableListener({ source ->
            if (pending.compareAndSet(true, false)) {
                timeout?.let(handler::removeCallbacks)
                val image = source.acquireLatestImage()
                if (image != null) {
                    try { saveFrame(image) } finally { image.close() }
                }
                showPanel()
            } else {
                source.acquireLatestImage()?.close()
            }
        }, handler)

        display = projection?.createVirtualDisplay(
            "ScreenshotPDF", metrics.widthPixels, metrics.heightPixels, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, handler
        )
        showPanel()
        return START_NOT_STICKY
    }

    private fun makePanel(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(0xEE173B75.toInt())
        }
        status = TextView(this).apply { setTextColor(0xFFFFFFFF.toInt()); text = "撮影済み: 0" }
        root.addView(status)
        fun button(label: String, action: () -> Unit) {
            root.addView(Button(this).apply { text = label; setOnClickListener { action() } })
        }
        button("手動撮影") { takeShot() }
        button("自動撮影 開始 / 停止") {
            auto = !auto
            handler.removeCallbacks(autoTask)
            if (auto) handler.post(autoTask)
            status.text = "撮影済み: $count / 自動: ${if (auto) "ON" else "OFF"}"
        }
        button("パネルを隠す") { hidePanel() }
        button("終了") { stopSelf() }
        return root
    }

    private fun showPanel() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { showPanel() }; return
        }
        if (panel == null) panel = makePanel()
        status.text = "撮影済み: $count / 自動: ${if (auto) "ON" else "OFF"}"
        if (panelAdded) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 10; y = 140 }
        try { wm?.addView(panel, params); panelAdded = true } catch (_: Exception) {}
    }

    private fun hidePanel() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { hidePanel() }; return
        }
        if (panelAdded) {
            try { wm?.removeView(panel) } catch (_: Exception) {}
            panelAdded = false
        }
    }

    private fun takeShot() {
        if (!pending.compareAndSet(false, true)) return
        hidePanel()
        handler.postDelayed({
            timeout = Runnable { if (pending.compareAndSet(true, false)) showPanel() }
            handler.postDelayed(timeout!!, 2200L)
        }, 350L)
    }

    private fun saveFrame(image: Image) {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + rowPadding / pixelStride
        val padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        plane.buffer.rewind()
        padded.copyPixelsFromBuffer(plane.buffer)
        val bitmap = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "page_%05d.jpg".format(++count))
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/KindleScreenshotPDF")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            if (Build.VERSION.SDK_INT >= 29) {
                val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                contentResolver.update(uri, done, null, null)
            }
        }
        bitmap.recycle()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "画面取得", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        auto = false
        handler.removeCallbacks(autoTask)
        timeout?.let(handler::removeCallbacks)
        hidePanel()
        display?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
