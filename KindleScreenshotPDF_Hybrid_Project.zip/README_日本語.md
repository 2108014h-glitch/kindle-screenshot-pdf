# Kindle Screenshot PDF Hybrid

このスターターは2つのアプリで構成されます。

- `docs/`：PWA。画像を複数選択し、順番を調整してPDFにします。
- `android/`：Androidコンパニオン。ユーザーが許可した画面取得セッションで、撮影可能な画面を画像として保存します。

## 重要な制限
- Kindleが画面取得を禁止しているページは撮影できません。黒画面等になる場合があります。
- DRM、FLAG_SECURE、アクセス制御を解除・回避する機能はありません。
- 自動モードは一定間隔で撮影する機能です。ページ送りは手動です。
- 実機でのビルド・動作確認前のスターターコードです。まず自作資料など許可された画面で試してください。
- PWAのPDF生成ライブラリはCDNから読み込みます。初回はネット接続が必要です。

## スマホだけで進める

### 1. GitHubに配置
1. Android Chromeで https://github.com/signup にアクセスして登録・ログイン。
2. `kindle-screenshot-pdf` という新規リポジトリを作成。
3. ZIPをスマホのファイル管理アプリで展開。
4. `docs`、`android`、`.github` のフォルダを保ったままGitHubへアップロード。難しければChromeの「PC版サイト」またはGitHub Codespacesを利用。

### 2. PWAを公開
1. GitHubリポジトリの Settings → Pages。
2. Sourceを「Deploy from a branch」、Branchを `main`、Folderを `/docs` にして保存。
3. `https://ユーザー名.github.io/kindle-screenshot-pdf/` にアクセス。
4. Chromeメニューから「ホーム画面に追加」または「アプリをインストール」。

### 3. Android APKをビルド
1. Actions → `Build Android companion APK`。
2. `Run workflow` を実行。
3. 完了した実行を開き、Artifactsの `KindleScreenshotPDF-debug` をダウンロード。
4. ZIPを展開して `app-debug.apk` をインストール。必要なら「不明なアプリのインストール」を許可。
5. 初回に「他のアプリの上に重ねて表示」を許可し、アプリ内で画面取得を開始。

### 4. 使い方
1. Androidコンパニオンで画面取得を開始。
2. 撮影許可された画面で、浮動パネルの「手動撮影」または「自動撮影」を使う。
3. 画像は `Pictures/KindleScreenshotPDF` に保存。
4. PWAを開き「画像を選択」から複数画像を選ぶ。
5. 必要なら上下で順序を調整し、「PDFを作成」。

## 注意
大量の高解像度画像はメモリを多く使います。最初は10〜20枚でテストしてください。Androidのメーカー独自制限、省電力設定、OSバージョンにより追加調整が必要になることがあります。生成されるAPKはテスト用debug APKで、Playストア用の署名済みAPKではありません。
